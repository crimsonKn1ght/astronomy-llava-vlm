# AstroLLaVA full held-out evaluation

Stage: stage2
Config: configs/finetune_astrollava_stage2.yaml
Records: datasets/astrollava_llava/test.json
Images: datasets/astrollava_llava/images
Targets:
- stage2: checkpoints/astrollava-stage2/checkpoint-2526

Run:
python scripts/run_full_heldout_eval.py --stage stage2 --num-samples 0 --resume --package

Metrics are produced by scripts/score_predictions.py and include ROUGE-L, token-F1, exact match,
specificity hallucination, NLI consistency, contradiction rate, and SBERT cosine when enabled.
