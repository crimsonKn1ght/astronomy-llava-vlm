| model | split | n | rougeL | token_f1 | em_all | em_closed | em_open | specificity_halluc | unsupported_specifics | records_with_pred_specifics | sbert | nli | contradiction |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| stage2 | overall | 3271 | 0.3404 | 0.3948 | 0.0339 | 0.0000 | 0.0339 | 0.2284 | 0.3369 | 914 | 0.7313 | -0.0795 | 0.5436 |
| stage2 | caption | 586 | 0.1733 | 0.2307 | 0.0034 | 0.0000 | 0.0034 | 0.6058 | 1.0205 | 415 | 0.5913 | -0.1550 | 0.6706 |
| stage2 | qa | 2685 | 0.3769 | 0.4306 | 0.0406 | 0.0000 | 0.0406 | 0.1460 | 0.1877 | 499 | 0.7619 | -0.0631 | 0.5158 |
