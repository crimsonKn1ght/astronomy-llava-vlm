# AstroLLaVA full held-out evaluation

Stage: stage1
Config: configs/pretrain_astrollava.yaml
Records: datasets/astrollava_llava/test.json
Images: datasets/astrollava_llava/images
Targets:
- stage1_ep1: checkpoints/astrollava-stage1/checkpoint-1300
- stage1_ep2: checkpoints/astrollava-stage1/checkpoint-2500
- stage1_ep3: checkpoints/astrollava-stage1/checkpoint-3789

Run:
python scripts/run_full_heldout_eval.py --stage stage1 --num-samples 0 --resume --package

Metrics are produced by scripts/score_predictions.py and include ROUGE-L, token-F1, exact match,
specificity hallucination, NLI consistency, contradiction rate, and SBERT cosine when enabled.
