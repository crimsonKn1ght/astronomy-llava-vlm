# Qwen2.5-VL full held-out baseline

Model: Qwen/Qwen2.5-VL-7B-Instruct
Records: datasets/astrollava_llava/test.json
Images: datasets/astrollava_llava/images
Output directory: eval_runs/full_heldout/qwen2_5_vl_7b

Run:
python scripts/run_qwen_vl_full_heldout_eval.py --num-samples 0 --resume --package

This is an external general VLM baseline. It is not an AstroLLaVA checkpoint and is not trained by
this repository.

Metrics are produced by scripts/score_predictions.py and include ROUGE-L, token-F1, exact match,
specificity hallucination, NLI consistency, contradiction rate, and SBERT cosine when enabled.
