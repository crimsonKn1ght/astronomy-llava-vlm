| model | split | n | rougeL | token_f1 | em_all | em_closed | em_open | specificity_halluc | unsupported_specifics | records_with_pred_specifics | sbert | nli | contradiction |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| qwen2_5_vl_7b | overall | 3271 | 0.1610 | 0.2156 | 0.0003 | 0.0000 | 0.0003 | 0.2727 | 0.4946 | 988 | 0.6224 | 0.0281 | 0.1764 |
| qwen2_5_vl_7b | caption | 586 | 0.1327 | 0.1969 | 0.0017 | 0.0000 | 0.0017 | 0.1980 | 0.3379 | 167 | 0.5347 | 0.1108 | 0.0734 |
| qwen2_5_vl_7b | qa | 2685 | 0.1672 | 0.2197 | 0.0000 | 0.0000 | 0.0000 | 0.2890 | 0.5289 | 821 | 0.6416 | 0.0100 | 0.1989 |
