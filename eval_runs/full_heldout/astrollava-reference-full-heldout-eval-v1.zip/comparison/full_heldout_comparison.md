| model | split | n | rougeL | token_f1 | em_all | em_closed | em_open | specificity_halluc | unsupported_specifics | records_with_pred_specifics | sbert | nli | contradiction |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| astrollava_reference | overall | 3240 | 0.1759 | 0.1993 | 0.0000 | 0.0000 | 0.0000 | 0.1722 | 0.2207 | 607 | 0.4656 | 0.0101 | 0.5836 |
| astrollava_reference | caption | 586 | 0.0939 | 0.0916 | 0.0000 | 0.0000 | 0.0000 | 0.4283 | 0.6195 | 258 | 0.3758 | -0.1375 | 0.8225 |
| astrollava_reference | qa | 2654 | 0.1941 | 0.2230 | 0.0000 | 0.0000 | 0.0000 | 0.1157 | 0.1326 | 349 | 0.4854 | 0.0426 | 0.5309 |
