# AstroLLaVA reference full held-out baseline

Model: UniverseTBD/AstroLLaVA
Backend: llava
Records: datasets/astrollava_llava/test.json
Images: datasets/astrollava_llava/images
Output directory: eval_runs/full_heldout/astrollava_reference

Run:
python scripts/run_astrollava_reference_full_heldout_eval.py --num-samples 0 --resume --package

This is a domain reference baseline with possible overlap against this repository's held-out split,
because the reference model was trained on the same AstroLLaVA data lineage. Treat it as a
domain comparator, not as a clean external benchmark.

Metrics are produced by scripts/score_predictions.py and include ROUGE-L, token-F1, exact match,
specificity hallucination, NLI consistency, contradiction rate, and SBERT cosine when enabled.
